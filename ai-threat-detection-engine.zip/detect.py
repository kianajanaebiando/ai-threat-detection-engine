
import pandas as pd
from sklearn.ensemble import IsolationForest

data = pd.read_csv("sample_logs.csv")
model = IsolationForest(contamination=0.02)
data["anomaly"] = model.fit_predict(data[["value"]])
print(data.head())
